# Changelog

## 0.3.4

- Quadrupled the room: it is now 6×6 cells (12 m square) instead of 3×3, with extra lighting so
  the larger interior is not half dark.
- The wall set slider now swaps the whole **tile set** rather than another prefab from the same
  set. Every complete wall set in the game is listed, the Grove's sets first, and each set is
  filtered out if its dungeon uses a different tile size to the room.
- Flipped every wall 180 degrees about its own pivot, so the textured face points into the room
  instead of showing the walls' backs.
- The wall set list is written to the log, so a config index can be matched to a set by name.

## 0.3.3

- Rebuilt the room walls so they close properly and face inward. Wall prefabs are now placed the
  way the game's own dungeon generator places them: cell centre plus the prefab's authored
  offset with an identity rotation. The old code applied each prefab's rotation, which turned
  the walls inside out and shifted them off the cell edges, leaving gaps.
- Every boundary cell of the room now gets its wall pieces, including all four outer corners, so
  the perimeter has no missing sections.
- Added a **Storage room wall type** slider to FATE Mod Menu that cycles the room's wall prefab
  style and rebuilds the walls live. It is stored in the config as `Walls.Style` and also works
  without FATE Mod Menu installed.
- The entrance's minimap icon is now a chest instead of a diamond, so the marker reads as
  storage at a glance.
- The diagnostic overlay shows the active wall style.

## 0.3.2

- Moved the default Grove entrance to the open spot beside the fishing dock at 32.7, 0.5, 9.5,
  with ground and NavMesh snapping. The old house-based placement is kept as a fallback if that
  spot ever stops being walkable.
- Exit teleport also uses a NavMesh-sampled point near the entrance, so leaving the room does not
  drop the player into the door or a wall.

## 0.3.1

- The diagnostic overlay now shows the player's live XYZ coordinates and the entrance, dock and
  house positions.
- F10 writes the player and entrance coordinates to the log, so a bad entrance spot can be
  reported without copying numbers off the screen.
- Added `Entrance.ManualPosition` for an exact x,y,z entrance position and `Entrance.Offset` to
  nudge the automatic spot; both are read when the entrance is created, so no rebuild is needed.
- Entrance creation logs the full dock/house/door/return coordinates.

## 0.3.0

- Restored the village storage entrance beside the house behind the fishing dock. It is created
  when the Grove finishes loading and is recreated after every town reload.
- Restored the minimap marker, the gold light beam and the floating diamond at the entrance.
- The entrance is placed on the interaction layer and gets its own clamped hitbox, while the
  copied dungeon-door's child colliders are switched off so the prompt stays at the doorway.
- Interacting with the entrance now returns the player to its doorstep on exit; F9 remains a
  debug entry that returns the player to where the key was pressed.
- Dock lookup falls back from the named dock to any fishing dock object and then to the fishing
  spots; if none is found the entrance is placed beside the player with a logged warning.

## 0.2.1

- Replaced the primitive test room with a 3×3 room assembled from the Grove dungeon's existing floor, wall and ceiling prefabs.
- Restored three persistent storage chests using the character's save slot, with contents loaded from and written to the sidecar save file.
- Moved F9 handling and Grove detection to a Harmony patch on the game's Player.Update, with the plugin update loop as a fallback, so they no longer depend on runtime manager callbacks that the game destroys during scene loads.
- Recreates the manager and diagnostic overlay at runtime if the game removes the startup objects.
- Added scene/manager/F9 diagnostic logging and an expanded on-screen status panel.
- A NavMesh bake failure no longer discards the built room.
- Teleporting now also assigns the player position directly as a fallback for the off-NavMesh room.
- Synchronizes physics transforms and bakes the room NavMesh with the player's own agent type.

## 0.2.0

- Replaced the entrance/search path with a minimal F9 test room.
- The test room has two 2x2 floor squares, a closed shell, lights and one exit door.
- F9 now builds the room and teleports the player directly into it; F9 or the exit door returns the player.
- Disabled village entrance, minimap marker and storage chest placement for this test build.

## 0.1.4

- Added a temporary on-screen diagnostic overlay showing town, player, entrance and room status.
- Added F9 to toggle the storage room directly for testing.
- Added `Diagnostics.ShowDebugOverlay` config; it defaults to enabled during diagnosis.

## 0.1.3

- Made plugin startup non-fatal: the room manager is created before optional Harmony patches, so a failed patch cannot remove the whole feature.
- Added a guaranteed fallback entrance at the player spawn if house detection or the dungeon-entrance template fails.
- Pre-builds the room when the Grove loads so room construction errors are logged immediately.
- Added detailed setup logs for the manager, town detection, interaction layer and entrance creation.

## 0.1.2

- Rebuilt the entrance from the game's own dungeon-door/portal object, preserving its collider and interaction layer.
- Removed the custom chest hitbox that was not being picked up by the player interaction scan.
- Added a high-contrast minimap marker, a gold light beam and a floating diamond marker at the entrance.
- Added logging for the copied template, entrance layer and marker creation.

## 0.1.1

- Replaced the wall-mounted entrance with a visible storage chest placed in the open beside the fishing-dock house.
- Added a chest icon on the minimap so the entrance is easy to find.
- Increased the entrance interaction range and priority so it is easier to use near the house.

## 0.1.0

- Added the permanent Grove storage room behind the fishing-dock house.
- Added seven independently unlockable storage chests using the stock Storage Chest UI.
- Added gold and Mimic Chest unlock paths with confirmation prompts.
- Added the Mimic Chest item, runtime icon and world-drop model, with a configurable Mimic drop chance.
- Added slot-keyed sidecar persistence for unlocks and chest contents.
- Added Grove music, warm lighting and a fixed room built from the Grove dungeon tile set.
