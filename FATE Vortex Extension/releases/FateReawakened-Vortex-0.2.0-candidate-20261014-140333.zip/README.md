# FATE: Reawakened Vortex support (0.2.0 candidate)

Install this extension archive through Vortex's Extensions page and restart Vortex. Manage FATE: Reawakened, selecting its Steam installation manually if discovery fails. This extension is for the remaster, not the original FATE game.

When managing the game or installing a mod, the extension checks for the BepInEx loader. If missing, close FATE and select **Install BepInEx** in the notification. Vortex downloads the official pinned BepInEx 5.4.23.5 Windows x64 ZIP from GitHub, installs it as a separate mod and enables it in the selected FATE profile. Click **Deploy Mods** with the game closed. Then install, enable and deploy the co-op plugin ZIP and launch using **Steam Library → Play**.

Existing loader installations are left alone. A loader already installed through this helper but not deployed prompts for deployment instead of another download. Download failures show an error and can be retried; the official ZIP can still be manually imported as a fallback. This helper does not automatically update existing loaders or deploy files into a running game. Vortex extension approval is separate from Nexus mod downloads.

Updates: close the game, install the new plugin archive, choose to replace the previous version, enable and deploy. Keep only one co-op plugin version active. The installer replaces plugin/documentation files and leaves saves, configuration and transaction journals alone. Everyone in a lobby needs the same build. Do not delete mod state to work around an interrupted item or XP transfer.

Archive installers accept our standard nested BepInEx plugin layout and the official Mono loader layout. They ignore save/config/game files and reject unsafe paths or duplicate destination files. Other mod layouts require their own installer support.

This is a development candidate: installer fixtures pass; live Vortex discovery, deployment and updates still need verification. It has not been submitted to Nexus for extension review.
