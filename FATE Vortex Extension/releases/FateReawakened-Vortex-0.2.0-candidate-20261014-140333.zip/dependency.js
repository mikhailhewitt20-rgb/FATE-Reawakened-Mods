'use strict';
const path = require('path');
const GAME = 'fatereawakened';
const ID = 'fate-bepinex-required';
const FILE = 'BepInEx_win_x64_5.4.23.5.zip';
const URL = 'https://github.com/BepInEx/BepInEx/releases/download/v5.4.23.5/' + FILE;
const running = new WeakMap();
async function exists(fs, file) {
  try { return (await fs.statAsync(file)).isFile(); }
  catch (err) { if (err.code === 'ENOENT') return false; throw err; }
}
async function check(api, gamePath, deps) {
  const required = ['winhttp.dll', 'doorstop_config.ini', 'BepInEx/core/BepInEx.dll'];
  if ((await Promise.all(required.map(file => exists(deps.fs, path.join(gamePath, file))))).every(Boolean)) {
    api.dismissNotification(ID); return;
  }
  const mods = api.getState().persistent?.mods?.[GAME] || {};
  if (Object.values(mods).some(mod => mod.attributes?.fateBepInExLoader)) {
    api.sendNotification({ id: ID, type: 'warning', title: 'BepInEx needs deployment',
      message: 'BepInEx is installed in Vortex. Enable it for this profile and Deploy Mods with FATE closed.', allowSuppress: false });
    return;
  }
  api.sendNotification({ id: ID, type: 'warning', title: 'FATE Co-op requires BepInEx',
    message: 'Close FATE, then install BepInEx 5.4.23.5 Windows x64 from its official GitHub release. It will be a separate Vortex mod.',
    allowSuppress: false, actions: [{ title: 'Install BepInEx', action: () => install(api, deps) }] });
}
function install(api, deps) {
  if (running.has(api)) return running.get(api);
  const work = (async () => {
    api.sendNotification({ id: ID + '-installing', type: 'activity', message: 'Downloading and installing BepInEx', noDismiss: true });
    try {
      // Capture the intended profile before downloading; never enable in another game after a switch.
      const profile = deps.selectors.lastActiveProfileForGame(api.getState(), GAME);
      if (!profile) throw new Error('Select a FATE: Reawakened profile first.');
      const download = await new Promise((resolve, reject) => api.events.emit('start-download', [URL],
        { game: GAME, name: 'BepInEx 5.4.23.5 Windows x64' }, FILE,
        (err, id) => err ? reject(err) : resolve(id), undefined, { allowInstall: false }));
      if (!download) throw new Error('Vortex did not return a download ID.');
      const mod = await new Promise((resolve, reject) => api.events.emit('start-install-download', download,
        { allowAutoEnable: false }, (err, id) => err ? reject(err) : resolve(id)));
      if (!mod) throw new Error('Vortex did not return an installed mod ID.');
      api.store.dispatch(deps.actions.setModAttribute(GAME, mod, 'fateBepInExLoader', true));
      await deps.actions.setModsEnabled(api, profile, [mod], true, { allowAutoDeploy: false, installed: true });
      api.dismissNotification(ID);
      api.sendNotification({ id: ID + '-ready', type: 'success', message: 'BepInEx installed and enabled. With FATE closed, Deploy Mods, then launch using Steam Library → Play.' });
    } catch (err) {
      api.showErrorNotification('BepInEx setup failed — retry or install the official ZIP manually', err, { allowReport: false });
    } finally { api.dismissNotification(ID + '-installing'); }
  })();
  running.set(api, work);
  work.finally(() => running.delete(api));
  return work;
}
module.exports = { check, install, URL, FILE };
