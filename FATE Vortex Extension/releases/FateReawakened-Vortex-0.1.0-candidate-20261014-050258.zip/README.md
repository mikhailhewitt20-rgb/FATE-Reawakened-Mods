# FATE: Reawakened Vortex support (0.1.0 candidate)

Install this extension archive through Vortex's Extensions page and restart Vortex. Manage FATE: Reawakened, selecting its Steam installation manually if discovery fails. This extension is for the remaster, not the original FATE game.

Install the official [BepInEx 5.4.23.5 Windows x64 archive](https://github.com/BepInEx/BepInEx/releases/tag/v5.4.23.5) as a separate Vortex mod, enable and deploy it. Then install, enable and deploy the co-op plugin archive. Launch through Steam; launching through Vortex is optional. The support extension does not download dependencies automatically.

Updates: close the game, install the new plugin archive, choose to replace the previous version, enable and deploy. Keep only one co-op plugin version active. The installer replaces plugin/documentation files and leaves saves, configuration and transaction journals alone. Everyone in a lobby needs the same build. Do not delete mod state to work around an interrupted item or XP transfer.

Archive installers accept our standard nested BepInEx plugin layout and the official Mono loader layout. They ignore save/config/game files and reject unsafe paths or duplicate destination files. Other mod layouts require their own installer support.

This is a development candidate: installer fixtures pass; live Vortex discovery, deployment and updates still need verification. It has not been submitted to Nexus for extension review.
