'use strict';
const path = require('path');
const { fs, util } = require('vortex-api');
const installer = require('./installer');
function main(context) {
  context.registerGame({
    id: installer.GAME_ID,
    name: 'FATE: Reawakened',
    mergeMods: true,
    queryPath: () => util.GameStoreHelper.findByAppId(['3030720']).then(game => game.gamePath),
    queryModPath: () => '.',
    executable: () => 'FateReawakened.exe',
    requiredFiles: ['FateReawakened.exe', 'FateReawakened_Data/Managed/Assembly-CSharp.dll'],
    supportedTools: [],
    setup: discovery => fs.ensureDirAsync(path.join(discovery.path, 'BepInEx', 'plugins')),
    details: { steamAppId: '3030720', nexusPageId: installer.GAME_ID },
  });
  context.registerInstaller('fate-reawakened-bepinex', 25, installer.testSupported, installer.install);
  return true;
}
module.exports = { default: main };
