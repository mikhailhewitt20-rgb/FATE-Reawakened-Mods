'use strict';
// Only deploy our plugin or the official Mono BepInEx loader. Save/config data is never an update payload.
const GAME_ID = 'fatereawakened';
const PLUGIN = 'BepInEx/plugins/FateDiagnostics/FateDiagnostics.dll';
function entries(files) {
  return files.filter(f => !/[\\/]$/.test(f)).map(source => {
    const normalized = source.replace(/\\/g, '/');
    if (/^[\/]|:|[\x00-\x1f]/.test(normalized) || normalized.split('/').some(p => !p || p === '..' || p === '.')) {
      throw new Error('Unsafe archive path');
    }
    return { source, normalized };
  });
}
function rootFor(list, suffix) {
  const matches = list.filter(e => e.normalized.toLowerCase() === suffix.toLowerCase()
    || e.normalized.toLowerCase().endsWith('/' + suffix.toLowerCase()));
  if (matches.length !== 1) return undefined;
  return matches[0].normalized.slice(0, -suffix.length);
}
function plan(files) {
  const list = entries(files);
  const pluginRoot = rootFor(list, PLUGIN);
  if (pluginRoot !== undefined) {
    const allowed = new Map([[PLUGIN.toLowerCase(), PLUGIN], ['readme.md', 'BepInEx/plugins/FateDiagnostics/README.md'],
      ['release_plan.md', 'BepInEx/plugins/FateDiagnostics/RELEASE_PLAN.md'], ['manifest.json', 'BepInEx/plugins/FateDiagnostics/manifest.json']]);
    return list.filter(e => e.normalized.startsWith(pluginRoot)).flatMap(e => {
      const destination = allowed.get(e.normalized.slice(pluginRoot.length).toLowerCase());
      return destination ? [{ type: 'copy', source: e.source, destination }] : [];
    });
  }
  const loaderRoot = rootFor(list, 'winhttp.dll');
  if (loaderRoot !== undefined) {
    const relative = list.filter(e => e.normalized.startsWith(loaderRoot))
      .map(e => ({ ...e, relative: e.normalized.slice(loaderRoot.length) }));
    if (!['doorstop_config.ini', 'bepinex/core/bepinex.dll'].every(p => relative.some(e => e.relative.toLowerCase() === p))) return [];
    return relative.filter(e => ['winhttp.dll', 'doorstop_config.ini', '.doorstop_version'].includes(e.relative.toLowerCase())
      || /^bepinex\/core\/[^/]+\.(dll|xml)$/i.test(e.relative))
      .map(e => ({ type: 'copy', source: e.source, destination: e.relative }));
  }
  return [];
}
async function testSupported(files, gameId) {
  if (gameId !== GAME_ID) return { supported: false, requiredFiles: [] };
  try { return { supported: plan(files).length > 0, requiredFiles: [] }; }
  catch { return { supported: false, requiredFiles: [] }; }
}
async function install(files) {
  const instructions = plan(files);
  if (!instructions.length) throw new Error('Unsupported FATE: Reawakened archive');
  const destinations = instructions.map(i => i.destination.toLowerCase());
  if (new Set(destinations).size !== destinations.length) throw new Error('Duplicate deployment destinations');
  instructions.push({ type: 'attribute', key: instructions.some(i => i.destination.toLowerCase() === PLUGIN.toLowerCase())
    ? 'fateCoopPlugin' : 'fateBepInExLoader', value: true });
  return { instructions };
}
module.exports = { GAME_ID, testSupported, install, plan };
