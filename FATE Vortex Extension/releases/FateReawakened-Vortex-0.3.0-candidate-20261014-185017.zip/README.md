# FATE: Reawakened Vortex support (0.3.0 open alpha)

Install this extension archive through Vortex's Extensions page and restart Vortex. Manage FATE: Reawakened, selecting its Steam installation manually if discovery fails. This extension is for the remaster, not the original FATE game.

With this extension installed and FATE managed in Vortex, close the game and click **Install FATE Co-op** in the Mods toolbar or setup notification. The helper downloads the current main co-op file from Nexus, installs missing BepInEx 5.4.23.5 Windows x64 from official GitHub, enables the required mods, disables older recognized co-op versions in this profile and deploys. It checks that the plugin and loader files are present before reporting success. Launch with **Steam Library → Play**.

Nexus account/download approvals (including the free-account download page), deployment elevation and first-time game/extension setup may still need user interaction. Installing Vortex alone does not install this game extension. Virus scanning does not approve the extension into Vortex's catalog or enable Nexus's Mod Manager Download button for this game. Once an NXM download is installed through this extension, its post-install hook completes the loader, enabling and deployment steps automatically.

Existing deployed loaders are left alone. Staged loaders recognized by the extension are enabled and deployed rather than downloaded again. Duplicate clicks share one setup operation. Download/install/enable/deployment failures show an error and Retry setup; switching away from the target profile or starting a tracked game/tool stops completion. The official ZIPs can still be manually imported as a fallback. This helper does not update existing loaders or delete saves, config, receipts or ReShade.

Updates: close the game, install the new plugin archive, choose to replace the previous version, enable and deploy. Keep only one co-op plugin version active. The installer replaces plugin/documentation files and leaves saves, configuration and transaction journals alone. Everyone in a lobby needs the same build. Do not delete mod state to work around an interrupted item or XP transfer.

Archive installers accept our standard nested BepInEx plugin layout and the official Mono loader layout. They ignore save/config/game files and reject unsafe paths or duplicate destination files. Other mod layouts require their own installer support.

Automated installer and setup workflow checks pass. The event/attribute/action contracts were inspected in the installed Vortex source map. Live Vortex discovery/download/deployment and Nexus handoff still need verification; simulated tests do not certify the full desktop flow. This extension is not approved for the built-in catalog.
