'use strict';
const path = require('path');
const { fs, util, actions, selectors } = require('vortex-api');
const installer = require('./installer');
const setup = require('./setup');
function main(context) {
  context.registerGame({
    id: installer.GAME_ID,
    name: 'FATE: Reawakened',
    mergeMods: true,
    queryPath: () => util.GameStoreHelper.findByAppId(['3030720']).then(game => game.gamePath),
    queryModPath: () => '.',
    executable: () => 'FateReawakened.exe',
    requiredFiles: ['FateReawakened.exe', 'FateReawakened_Data/Managed/Assembly-CSharp.dll'],
    supportedTools: [],
    setup: async discovery => {
      await fs.ensureDirAsync(path.join(discovery.path, 'BepInEx', 'plugins'));
      await setup.offer(context.api, discovery.path, { fs, actions, selectors });
    },
    details: { steamAppId: '3030720', nexusPageId: installer.GAME_ID },
  });
  context.registerInstaller('fate-reawakened-bepinex', 25, installer.testSupported, installer.install);
  const deps = { fs, actions, selectors };
  context.registerAction('mod-icons', 25, 'start-install', {}, 'Install FATE Co-op',
    () => setup.run(context.api, deps), () => selectors.activeGameId(context.api.getState()) === installer.GAME_ID);
  context.once(() => {
    const check = async gameId => {
      if (gameId !== installer.GAME_ID) return;
      const discovery = selectors.discoveryByGame(context.api.getState(), gameId);
      if (discovery?.path) {
        try { await setup.offer(context.api, discovery.path, deps); }
        catch (err) { context.api.showErrorNotification('Could not check FATE BepInEx installation', err, { allowReport: false }); }
      }
    };
    context.api.events.on('gamemode-activated', check);
    context.api.events.on('did-install-mod', (gameId, archiveId, modId) => {
      if (gameId === installer.GAME_ID && !setup.isBusy(context.api)
          && context.api.getState().persistent?.mods?.[gameId]?.[modId]?.attributes?.fateCoopPlugin) {
        return setup.run(context.api, deps, modId);
      }
    });
  });
  return true;
}
module.exports = { default: main };
