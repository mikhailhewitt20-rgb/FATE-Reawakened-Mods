'use strict';
const path = require('path');
const crypto = require('crypto');
const dependency = require('./dependency');
const GAME = 'fatereawakened';
const PLUGIN = 'BepInEx/plugins/FateDiagnostics/FateDiagnostics.dll';
const REQUIRED = ['winhttp.dll', 'doorstop_config.ini', 'BepInEx/core/BepInEx.dll'];
const busy = new WeakMap();
const ID = 'fate-coop-setup';
function context(api, deps) {
  const state = api.getState();
  const profile = deps.selectors.activeProfile(state);
  const discovery = deps.selectors.discoveryByGame(state, GAME);
  if (!profile || profile.gameId !== GAME || !discovery?.path) throw new Error('Manage FATE: Reawakened and select its profile first.');
  return { profile: profile.id, root: discovery.path };
}
function guard(api, deps, target) {
  const current = context(api, deps);
  if (current.profile !== target.profile || current.root !== target.root) throw new Error('The selected game/profile changed. Return to the original FATE profile and retry setup.');
  // Vortex itself skips deployment while any tracked game/tool runs; do not report that as success.
  if (Object.keys(api.getState().session?.base?.toolsRunning || {}).length) throw new Error('Close the running game/tools before installing FATE Co-op, then retry.');
}
async function exists(fs, file) {
  try { return (await fs.statAsync(file)).isFile(); }
  catch (err) { if (err.code === 'ENOENT') return false; throw err; }
}
function mods(api) { return api.getState().persistent?.mods?.[GAME] || {}; }
async function download(api, url, name, file) {
  const id = await new Promise((resolve, reject) => api.events.emit('start-download', [url], { game: GAME, name }, file,
    (err, value) => err ? reject(err) : resolve(value), undefined, { allowInstall: false }));
  if (!id) throw new Error('Vortex did not return a download ID.');
  return id;
}
async function installDownload(api, id) {
  const mod = await new Promise((resolve, reject) => api.events.emit('start-install-download', id,
    { allowAutoEnable: false }, (err, value) => err ? reject(err) : resolve(value)));
  if (!mod) throw new Error('Vortex did not return an installed mod ID.');
  return mod;
}
function run(api, deps, existingPlugin) {
  if (busy.has(api)) return busy.get(api);
  const work = (async () => {
    api.sendNotification({ id: ID, type: 'activity', message: 'Installing FATE Co-op and its loader', noDismiss: true });
    try {
      const target = context(api, deps);
      guard(api, deps, target);
      let plugin = existingPlugin;
      if (!plugin) {
        if (api.ext?.ensureLoggedIn) await api.ext.ensureLoggedIn();
        if (!api.ext?.nexusGetModFiles) throw new Error('Vortex Nexus integration is unavailable. Sign in to Nexus in Vortex.');
        const files = await api.ext.nexusGetModFiles(GAME, 12);
        const main = files.filter(f => Number(f.category_id) === 1 && !f.is_archived)
          .sort((a, b) => Number(b.uploaded_timestamp ?? b.uploaded_time) - Number(a.uploaded_timestamp ?? a.uploaded_time))[0];
        if (!main?.file_id) throw new Error('No current main co-op file found on Nexus.');
        plugin = Object.entries(mods(api)).find(([, m]) => m.state === 'installed'
          && m.attributes?.fateCoopPlugin && Number(m.attributes?.fileId) === Number(main.file_id))?.[0];
        if (!plugin) {
          const archive = await download(api, `nxm://${GAME}/mods/12/files/${main.file_id}`, 'FATE Co-op', undefined);
          guard(api, deps, target);
          plugin = await installDownload(api, archive);
        }
      }
      if (!mods(api)[plugin]?.attributes?.fateCoopPlugin) throw new Error('Selected mod is not a recognized FATE Co-op package.');
      guard(api, deps, target);
      const loaderInstalled = (await Promise.all(REQUIRED.map(f => exists(deps.fs, path.join(target.root, f))))).every(Boolean);
      let loader = Object.entries(mods(api)).find(([, m]) => m.state === 'installed' && m.attributes?.fateBepInExLoader)?.[0];
      if (!loaderInstalled && !loader) {
        const archive = await download(api, dependency.URL, 'BepInEx 5.4.23.5 Windows x64', dependency.FILE);
        guard(api, deps, target);
        loader = await installDownload(api, archive);
      }
      guard(api, deps, target);
      const previous = Object.entries(mods(api)).filter(([id, m]) => id !== plugin && m.attributes?.fateCoopPlugin).map(([id]) => id);
      await deps.actions.setModsEnabled(api, target.profile, previous, false, { allowAutoDeploy: false });
      await deps.actions.setModsEnabled(api, target.profile, [plugin, ...(!loaderInstalled && loader ? [loader] : [])], true,
        { allowAutoDeploy: false, installed: true });
      const profile = deps.selectors.activeProfile(api.getState());
      if (!profile.modState?.[plugin]?.enabled || (!loaderInstalled && !profile.modState?.[loader]?.enabled)) {
        throw new Error('Vortex could not enable the required mods. Check its notifications and retry.');
      }
      guard(api, deps, target);
      await new Promise((resolve, reject) => api.events.emit('deploy-mods', err => err ? reject(err) : resolve(), target.profile,
        undefined, { manual: true }));
      guard(api, deps, target);
      const deployed = await Promise.all([...REQUIRED, PLUGIN].map(f => exists(deps.fs, path.join(target.root, f))));
      if (!deployed.every(Boolean)) throw new Error('Deployment did not place all required files. Check Vortex deployment settings and retry.');
      const staging = deps.selectors.installPathForGame(api.getState(), GAME);
      const installedPath = mods(api)[plugin]?.installationPath;
      if (!staging || !installedPath) throw new Error('Could not verify the installed co-op package in the Vortex staging folder.');
      const expected = await deps.fs.readFileAsync(path.join(staging, installedPath, PLUGIN));
      const actual = await deps.fs.readFileAsync(path.join(target.root, PLUGIN));
      const hash = data => crypto.createHash('sha256').update(data).digest('hex');
      if (hash(expected) !== hash(actual)) throw new Error('The deployed co-op DLL differs from the installed package. Check Vortex file conflicts and retry.');
      api.dismissNotification(ID + '-offer');
      api.dismissNotification(ID + '-retry');
      api.dismissNotification(ID);
      api.sendNotification({ id: ID + '-ready', type: 'success', message: 'FATE Co-op and BepInEx are installed and deployed. Launch using Steam Library → Play.' });
      return true;
    } catch (err) {
      api.dismissNotification(ID);
      api.showErrorNotification('FATE Co-op setup could not finish', err, { allowReport: false });
      api.sendNotification({ id: ID + '-retry', type: 'warning', message: 'Fix the setup error, then retry. Your saves and ReShade are preserved.',
        actions: [{ title: 'Retry setup', action: () => run(api, deps, existingPlugin) }] });
      return false;
    }
  })();
  busy.set(api, work);
  work.finally(() => busy.delete(api));
  return work;
}
function isBusy(api) { return busy.has(api); }
async function offer(api, root, deps) {
  if ((await Promise.all([...REQUIRED, PLUGIN].map(f => exists(deps.fs, path.join(root, f))))).every(Boolean)) {
    api.dismissNotification(ID + '-offer'); api.dismissNotification('fate-bepinex-required'); return;
  }
  api.sendNotification({ id: ID + '-offer', type: 'info', title: 'FATE Co-op setup',
    message: 'Install the co-op mod and missing BepInEx, enable both and deploy with one action. Close FATE first.',
    actions: [{ title: 'Install FATE Co-op', action: () => run(api, deps) }] });
}
module.exports = { run, isBusy, offer };
